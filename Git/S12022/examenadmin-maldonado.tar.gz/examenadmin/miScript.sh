case $1 in
	1)
		echo "uno"
		;;
	2)
		echo "dos"
		;;
	3)
		echo "tres"
		;;
	4)
		echo "cuatro"
		;;
	5)
		echo "cinco"
		;;
	6)
		echo "seis"
		;;
	7)
		echo "siete"
		;;
	8)
		echo "ocho"
		;;
	9)
		echo "nueve"
		;;
        10)
		echo "diez"
		;;					
	*)
		echo "Ingresar solamente números del 1 al 10" 
		exit 1
		;;
esac


exit 0
