#!/bin/bash
entrada=$1

if [ $entrada = 1 ];then
    echo "uno"
elif [ $entrada = 2 ];then
    echo "dos"
else
    echo "Ingresar solamente números del 1 al 10."
fi
