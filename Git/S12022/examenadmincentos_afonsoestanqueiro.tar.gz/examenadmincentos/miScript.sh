#!/bin/bash

case $1 in
	1)
		echo "UNO"
		;;
	2)
		echo "DOS"
		;;
	3)
		echo "TRES"
		;;
	4)
		echo "CUATRO"
		;;
	5)
		echo "CINCO"
		;;
	6)
		echo "SEIS"
		;;
	7)
		echo "SIETE"
		;;
	8)
		echo "OCHO"
		;;
	9)
		echo "NUEVE"
		;;
	10)
		echo "DIEZ"
		;;
	*)
		echo "Ingresar solamente numeros del 1 al 10"
		;;
esac

